#!/usr/bin/perl
###############
# X-Chat Wrapper for webmadmin.pl,
# Usage:
#	!webban, !webkick, !weblist and !banip. If any of these commands are used in the admin_chan, it'll pass the rest of the line to WebAdmin.pl
#
# NOTE! Change the path to perl.exe and WebAdmin.pl in line 31 to where you have them. Forward slashes...
#
###############
# Don't edit stuff below here
#
use strict;
my $webk_version = "0.1";
my $admin_chan = "#myadminchannel";
my $test_chan = "#yourtestchannel";
Xchat::register( "Flashy's Webmin wrapper", "$webk_version", "Web", "" );
Xchat::hook_print('Channel Message', "webk_watch");
Xchat::hook_print('Your Message', "webk_watch"); 

# Start
Xchat::print("Loaded Flashy's Webkick Script v.$webk_version.");

sub webk_watch { # Main channel watch loop  - Check each config for triggers
		my @rowr = split(/ /,$_[0][1]);
		if ((Xchat::get_info('channel') eq $admin_chan) or (Xchat::get_info('channel') eq $test_chan)) {
			if (($rowr[0] eq '!webkick') or ($rowr[0] eq '!weblist') or ($rowr[0] eq '!webban') or ($rowr[0] eq '!banip')) {
				if ($rowr[1] eq '') { Xchat::command("say Error, no command. Usage: $rowr[0] SERVER (Nick/IP)"); return Xchat::EAT_NONE; }
				if ((($rowr[0] eq '!webkick') or ($rowr[0] eq '!webban') or ($rowr[0] eq '!banip')) and ($rowr[2] eq '')) {  Xchat::command("say Error, no NICK/IP. Usage: $rowr[0] SERVER Nick/IP"); return Xchat::EAT_NONE; }
				$rowr[0] =~ s/!//;				
				$rowr[1] =~ s/MPUK\|//gi;
				my $output = "exec -o cmd /c \"c:/perl/bin/perl.exe c:/kos/WebAdmin.pl $rowr[0] $rowr[1] $rowr[2] $rowr[3]\"";
				Xchat::print("Output: ($output)");
				Xchat::command($output);
			}
			
		}

	return Xchat::EAT_NONE;
	}

