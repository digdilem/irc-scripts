#!/usr/bin/perl
#
## Webadmin.pl - scrapes and controls via game web admins. By Flash_, proof of theory, 2007
# Currently supports the following games: 
#	UT99 / GOTY
#	UT2k4
# # Experimental
#
# Usage:
# perl webadmin.pl COMMAND SERVER_SHORTNAME (NICK/IP)
#
# Commands:
# weblist server (nick) = lists id/ip/nicks of all or optionally specific string
# webkick server NICK/IP = Kick nick or IP match (non-partial, case sensitive)
# webban server NICK/IP (2k4 - also GUID) - Ban and kick player by nick/ip or guid match
# banip server/* IP/Subnet.* (gametype) : Issue IP or subnet range ban on server.
#											NOTE! By replacing server name with '*' the ban will be extended to ALL servers.
#											If you wish to restrict mass ban to a single gametype, add gametype to the end;
#			Eg: To ban a single ip on one server: " banip servername 10.0.0.99 "
#			Eg: To ban a whole class C subnet on all servers: " banip * 10.0.0.* "
#			Eg: To ban a single IP on all servers of gametype "ut": " banip * 10.0.0.20 ut "
#
# To do
# banall IP/Subnet.* gametype - One-stop-shop to ban an ip or subnet on ALL the servers of gametype (eg, banall 10.0.0.* ut ) apply ban to all servers with ut gametype

use strict;
use LWP::UserAgent;
use CGI qw/unescapeHTML/;

my $password_ut = 'ut_99_password'; # Can define each below, this just makes it easier to bulk-change
my $password_2k4 = 'ut2k4_admin_pass';

# List all servers here, with their config details. These are a bunch of servers
my %CONFIG = ('local' => {	'gametype' => 'ut',
							'ip' => '127.0.0.1:85', # IP and port of the WEBADMIN - ** NOT ** the game port!
							'username' => 'admin',	# Name to log in with
							'password' => 'adminpass', # Password to log in with
							'nameslist_url' => '/ServerAdmin/current_players'}, # Path to current players page. Leave for unmodded ut99
			'ctf1' => {	'gametype' => 'ut',
							'ip' => '123.456.789.012:9999', 
							'username' => 'webadmin',
							'password' => $password_ut,
							'nameslist_url' => '/ServerAdmin/current_players'},
			# Now some ut2k4 ones
			'local2k4' => {	'gametype' => '2k4',
							'ip' => '127.0.0.1:85', 
							'username' => 'admin',
							'password' => $password_2k4,
							'nameslist_url' => '/ServerAdmin/current_players'},
			'dm12k4' => {	'gametype' => '2k4',
							'ip' => '123.456.789.012:10000',
							'username' => 'webadmin',
							'password' => $password_2k4, 
							'nameslist_url' => '/ServerAdmin/current_players'}					
			);

my $cline_command=shift; # arg1
my $cline_server=shift; # arg2
my $cline_nick=shift; # arg3
my $cline_gametype=shift; #arg4
my $hunted_id = 'unset';
my $kick_if_found=0;
my $ban_if_found=0;
my $ut2k4_bancount=0; # 2k4's screwy ban submission handling requires me to count existing bans

my $cline_found=0;
if (lc($cline_command) eq 'weblist') { get_player_names(); exit; }
if (lc($cline_command) eq 'webkick') { $kick_if_found=1; get_player_names(); exit; }
if (lc($cline_command) eq 'webban') { $ban_if_found=1; get_player_names(); exit; }
if (lc($cline_command) eq 'banip') { ban_ip(); exit; }

# If still here, I don't know the command used. Tell and bail.
print "Error: I don't know command '$cline_command'\n";
exit;

# Some global shared strings
my $url=0;
my $username=0;
my $password=0;
my $gametype=0;
my $map_name='';

# Call sub with $webadmin_ip, $webadmin_port, $webadmin_admin_name, $webadmin_admin_pass, $webadmin_gametype
sub get_player_names {
#	my $url="http://$webadmin_ip:$webadmin_port$webadmin_nameslist";
	my $found=0;
	my $func;
    for $func (keys %CONFIG) {
        next unless lc($cline_server) eq lc($func);
        $found = 1;
        $url = "http://" . $CONFIG{$func}->{'ip'} . $CONFIG{$func}->{'nameslist_url'}; 
		$username = $CONFIG{$func}->{'username'};
		$password = $CONFIG{$func}->{'password'};
		$gametype = $CONFIG{$func}->{'gametype'};		
		}
	# Quit if this isn't for us
	if ($found != 1) { print "Error - I don't know server $cline_server\n"; exit; }	

	my $ua = LWP::UserAgent->new;
	my $req = HTTP::Request->new(GET => $url);
	$req->authorization_basic($username, $password);
	my $output = $ua->request($req)->as_string;
	# Error check it
	if ($output =~ /500 Can\'t connect/) { print "Error 500 connecting. Server down or wrong config"; exit; }
	my $player_id, my $player_name, my $player_ip, my $player_guid, my @players;
	my $found_match=0;
	my $found_gametype=0;

	# Parse
	if (lc($gametype) eq 'ut') {  #####################  UT 99 SCAN
		$found_gametype++;
		$output =~ m/(KickPlayer.*)/;
	#	print "===$output\n";
		@players = split(/\/td><\/tr>/,$1);
	#	pop(@players); # Get rid of trailing one.
		if (scalar(@players) == 0) { print("No players on $cline_server\n"); exit; }
		foreach(@players) {
			$_ =~ s/&nbsp;//g; # Remove &nbsp's
			$_ =~  m/KickPlayer(\d+)/;  # Get player id
			$player_id = $1;
			$_ =~ m/div align=\"left\">(.*?)<\/div>/; # Get player nick
			$player_name = $1;
			$_ =~ /\b((\d{1,3}\.){3}\d{1,3})\b/;  # Find IP
			$player_ip = $1;	
		if  (defined $cline_nick) {
				my $foundhim=0;
				my $tmp_nick = $player_name;
				$tmp_nick =~ s/\(Spectator\)//;
				if (lc($cline_nick) eq lc($tmp_nick)) { $foundhim=1; }			
				# Also kick by IP
				if ($cline_nick eq $player_ip) { $foundhim=1; }			
				if ($foundhim == 1) { 
					print "Id: $player_id matches $cline_nick (IP: $tmp_nick / $player_ip)\n"; 
					$found_match++;
					if ($kick_if_found == 1) {
						kick_player($player_id);
						print "Kicked.\n";
						}
					if ($ban_if_found == 1) {
						ban_player($player_id);
						print "Banned IP: $player_ip from $cline_server\n"; 
					}
				}
	#			$$cline_nick is id: $player_id\n"; $hunted_id=$player_id; 		
			} else { if ($player_name ne $player_ip) { print "ID: $player_id \| $player_name $player_ip\n"; }} # Print full list after checking it's valid
		}	
	} # End UT scan stuff


	if (lc($gametype) eq '2k4') {  #####################  UT 2k4 SCAN
		$found_gametype++;
#		$output =~ m/(checkbox.*)/;
#		print "===$1\n";
		$output =~ m/class=ttext>(.*?)&nbsp;<\/td>/;
		$map_name = $1;
		@players = split(/tr align/,$output);
		shift @players; # rid ourselves of the first one
		if ($output =~ /\*\* No Players Connected \*\*/) { print("No players on $cline_server\n"); exit; }
		print scalar(@players) . " players in $map_name\n";
		foreach(@players) {
			$_ =~ s/&nbsp;//g; # Remove &nbsp's
			$_ =~  m/\'Kick(\d+)/;  # Get player id
			$player_id = $1;
			#print "Bum: ($_)\n";
			my @thing = split(/<td/,$_);
			# First line, nick
			$thing[3] =~ m/nowrap>(.*?)<\/td>/; # Get player nick
			$player_name = $1;
			$thing[6] =~  /\b((\d{1,3}\.){3}\d{1,3})\b/;  # Find IP
			$player_ip = $1;
			$thing[7] =~ m/center">*(.*?)<\/td>/;  # Find guid
			$player_guid = $1;	

		if  (defined $cline_nick) {
				my $foundhim=0;
				my $tmp_nick = $player_name;
				$tmp_nick =~ s/\(Spectator\)//;
				if (lc($cline_nick) eq lc($tmp_nick)) { $foundhim=1; }			
				# Also kick by IP
				if ($cline_nick eq $player_ip) { $foundhim=1; }			
				# Also kick by GUID
				if (lc($cline_nick) eq lc($player_guid)) { $foundhim=1; }			
				if ($foundhim == 1) { 
					print "Id: $player_id matches $cline_nick (IP: $tmp_nick / $player_ip / $player_guid)\n"; 
					$found_match++;
					if ($kick_if_found == 1) {
						kick_player($player_id);
						print "Kicked.\n";
						}
					if ($ban_if_found == 1) {
						ban_player($player_id);
						print "Banned IP: $player_ip from $cline_server\n"; 
						}
					}
	#			$$cline_nick is id: $player_id\n"; $hunted_id=$player_id; 		
				} else { print "ID: $player_id \| $player_name $player_ip $player_guid\n"; } # Print full list		
		}
	} # End UT 2k4 scan stuff
	
	if ($found_gametype == 0) { print "Error: Don't understand game type '$gametype'\n"; exit; }
	if (($found_match == 0) and ($cline_nick ne '')) { print "Player/IP: $cline_nick NOT found on server"; }
}

sub kick_player { 
	my $kick_id = shift;
	if ($kick_id eq '') { print "Error, no player id passed to kick function.\n"; exit; }
	print "Kicking player id: $kick_id\n";
	my $ua = new LWP::UserAgent;
	my $form = $url;
	my $post = new HTTP::Request 'POST',$form;
    $post->authorization_basic($username, $password);
	$post->content_type('application/x-www-form-urlencoded');
	my $Input;
	my $foundgame=0;
	if (lc($gametype) eq 'ut') {  #####################  UT  SCAN
		$Input="KickPlayer$kick_id=kick";
		$foundgame=1;
		}
	if (lc($gametype) eq '2k4') {  #####################  UT 2k4 SCAN
		$Input="Kick$kick_id=kick";		
		$foundgame=1;
		}
	if ($foundgame == 0) { print "Error/Kick: Unknown gametype $gametype"; exit; }

	$post->content($Input);
	my $res = $ua->request($post);

	if ($res->is_success) { } else { print "Submission failure: " . $res->status_line; }	
}

sub ban_player {  # Ban player
	my $ban_id = shift;
	if ($ban_id eq '') { print "Error, no player id passed to ban function.\n"; exit; }
	my $ua = new LWP::UserAgent;
	my $form = $url;
	my $post = new HTTP::Request 'POST',$form;
    $post->authorization_basic($username, $password);
	$post->content_type('application/x-www-form-urlencoded');
	my $foundgame=0;
	my $Input;
	if (lc($gametype) eq 'ut') {  #####################  UT  SCAN
		$Input="BanPlayer$ban_id=ban";
		$foundgame=1;
		}
	if (lc($gametype) eq '2k4') {  #####################  UT 2k4 SCAN
		$Input="Ban$ban_id=ban";
		$foundgame=1;
		}
	if ($foundgame == 0) { print "Error/Kick: Unknown gametype $gametype"; exit; }

#	print "Output: $Input\n";
	$post->content($Input);
	my $res = $ua->request($post);

	if ($res->is_success) { } else { print "Submission failure: " . $res->status_line; }	
}

sub ban_ip { # Ban the ip listed in $cline_nick on sever $cline_server
	print "Banning IP $cline_nick on server $cline_server\n";
	if ($cline_nick eq '') { print "Error, no IP passed to IPban function.\n"; exit; }
	if ($cline_nick eq '*') { print "Oooh, you didn't really want to ban ALL IP's. I'm going to do nothing instead.\n"; exit; }
	if ($cline_server eq '') { print "Error, no server ID passed to IPban function.\n"; exit; }
	my $func, my $found=0;
	if ($cline_server eq '*') { # Do all servers of gametype
		print "Global ban\n";
		for $func (keys %CONFIG) {
			$url = "http://" . $CONFIG{$func}->{'ip'} . '/ServerAdmin/defaults_ippolicy'; 
			$username = $CONFIG{$func}->{'username'};
			$password = $CONFIG{$func}->{'password'};
			$gametype = $CONFIG{$func}->{'gametype'};						
			 print "Banned $func/$gametype, "; 
			 ban_ip_part_two();
			}
		print "\nFinished mass ban routine ($cline_gametype)\n";
		} else { # treat as single server
		for $func (keys %CONFIG) {
			next unless lc($cline_server) eq lc($func);
			$found = 1;
			$url = "http://" . $CONFIG{$func}->{'ip'} . '/ServerAdmin/defaults_ippolicy'; 
			$username = $CONFIG{$func}->{'username'};
			$password = $CONFIG{$func}->{'password'};
			$gametype = $CONFIG{$func}->{'gametype'};		
			}
		if ($found != 1) { print "Error - I don't know server $cline_server\n"; exit; }	
		# Handle 2k4's requirement to know beforehand what the ban number is
		if ($gametype eq '2k4') { find_2k4s_bancount(); }
		ban_ip_part_two();
		}
	}

sub ban_ip_part_two {
	my $ua = new LWP::UserAgent;
	my $form = $url;
	my $post = new HTTP::Request 'POST',$form;
    $post->authorization_basic($username, $password);
	$post->content_type('application/x-www-form-urlencoded');
	my $foundgame=0;
	my $Input;
	if (lc($gametype) eq 'ut') {  #####################  UT SCAN
		$Input="AcceptDeny=DENY&IPMask=$cline_nick&Update=New"; # <- works fine
		$foundgame=1;
		}
	if (lc($gametype) eq '2k4') {  #####################  UT 2k4 SCAN
		$Input="IpNo=$ut2k4_bancount&AcceptDeny=DENY&IPMask=$cline_nick&Update=New";
		$foundgame=1;
		#defaults_ippolicy?IpNo=1
		}
	if ($foundgame == 0) { print "Error/Kick: Unknown gametype $gametype"; exit; }

	$post->content($Input);
	my $res = $ua->request($post);

	if ($res->is_success) { } else { print "Submission failure: " . $res->status_line; }	

	#print $res->as_string;
	}

sub find_2k4s_bancount {
	my $ua = LWP::UserAgent->new;
    my $banurl = $url;
	$banurl =~ s/current_players/defaults_ippolicy/;
#	print "Here! ($banurl)\n";
	my $req = HTTP::Request->new(GET => $banurl);
	$req->authorization_basic($username, $password);
	my $output = $ua->request($req)->as_string;

	$ut2k4_bancount = ($output =~ s/(IpNo=)/$1/g);  # Count existing bans
#	print "Done: $ut2k4_bancount\n";
	}
