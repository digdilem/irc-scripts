Scripts for X-Chat and Perl by Flash_.  2007
Designed to work both on Windows and Linux builds and to require the minimum configuration neccessary.
I can usually be found on Freenode (irc.freenode.net:6667) - #xchat

This script: Spamfilter

Overview: To allow the user to dynamically maintain a list of "spam" words he doesn't want to see. This can be anything from "Now Playing" to "is away (" to adverts in channels. This is probably the most powerful anti-spam filter around even though it's quite simple.


Features:
o  Optionally moves ALL filters to a seperate tab so you can check what's actually being removed.

o  Easy to add new spam words - just type: /addspam words to look for

o  List and delete entries just as easily with /showspam and /delspam Number

o  Specify channels NOT to filter on. Eg, you're an Op and need to see when somebody's doing something bad - just list your channel(s) and they won't be filtered. (See .pl and add to the @nofilter_chans array)

o  Also filter Join/Part/Quit/Modes/Topics if required. (Off by default)

o  Moved filters are displayed in an easy-to-read way, including number of spamfilter that triggered.


Additional Commands:
/ADDSPAM phrase   
Adds "phrase" to the spamfilter. Any line that comes in (whether said or acted) which contains this line (case insensitive) will be filtered. Can contain any number of words.
/SHOWSPAM
Displays the current list of spam phrases including their numbers.
/DELSPAM NUMBER
Deletes spam entry Number. Eg "/DELSPAM 9" will delete entry #9.


Additional Menus, buttons or Popups: 
None.

Defaults:  (All changeable)
	No filtering of Joins, Parts, Quits, Topics or Mode Changes (Enable each one in the .pl config section)
	Spamfiltering enabled but no phrases added. Use "/ADDSPAM phrase" to add new filter phrases.
	Config file will be auto created as "spamwords.txt" in your Xchat Config file.

Requirements: Perl(Linux) or Activeperl(Windows) installed and in the path. Xchat 2.0.8 or later. Freeware builds are fine.


===== Installation of script ======
Linux: X-Chat's default config directory is: ~/.xchat2 - simply copy the .pl file to this directory.

Windows: X-Chat's default folder is "C:\Documents and Settings\USERNAME\Application Data\X-Chat 2" 
(Change USERNAME and note that "Application Data" is Hidden so you'll need to Enable "See hidden files" in Explorer. 
If you find this daunting, in Xchat's Settings -> Preferences menu, under "Logging" there is a button to "Open Data Folder".
This opens an Explorer window in the right place.)

In both cases, Typing /reloadall in Xchat or restarting it will load the script. You should see an announcement in your current tab to that effect.
===================================