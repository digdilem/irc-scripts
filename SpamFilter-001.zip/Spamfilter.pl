#!/usr/bin/perl
use strict;
## Spamfilter. 
## Overview: Allows on-the-fly maintenance of a spamfilter and other "nuisance" lines.
# Key features: 
# Add/remove/list spam words. 
# Move all spam to one tab instead of simply deleting. (Shows which channel it came from)
# Filters joins/parts and mode/nick changes.
# Allows for "No-Filter" channels which are exempt from all filtering. (Ie, you're an op and need to know what's going on)
########
## By Flash_ ( irc.freenode.net #xchat  /  irc.quakenet.org #truff )
## Intended to be compatible, easily installed, easily used, portable and self-setting as much as is possible.
########
# Extra Commands given:
# "/ADDSPAM words"		Add a word or phrase to your spam filter. 
# "/SHOWSPAM"			Lists current spam list
# "/DELSPAM NUMBER"		Deletes spam entry #NUMBER (obtain number from /SHOWSPAM)
#
# Extra Menus/Buttons given: NONE
# Danger level: Minimal. 
##  Local disk access (config file - append/read/write). 
##  No channel output. (Local displays only)
# Installation - please read README.TXT
#######################################
# User Configuration Section
#######################################
my $spam_tab_name = 'spam'; # Name of tab to put spam into (Shouldn't be an existing channel)
my $spam_config = 'spamwords.txt'; # Name of a the config file to store the strings. Safe to leave alone, it will be created automatically.
my $showlist_current_tab = 1; # 1 to show the list in current tab. 0 to show it in the spam tab itself
#
my $send_to_spam_tab = 1; # 1 to send spam to spam channel, 0 to just eat it.
my $spamtab_colours = 1; # Set to 0 to turn off colours in spamtab
my $spamtab_col_chan = '11'; # Colour of channel in spamtab
my $spamtab_col_nick = '04'; # Colour of nicks in spamtab
my $spamtab_col_spam = '14'; # Colour of actual spam in spamtab
my $spamtab_col_event = '12'; # Colour of other events - Joins/parts/quits etc.
# Got any channels you want to see everything in? List them here (Format is ("#chan1","#chan2") etc. Many as you want.
my @nofilter_chans = ();
# Some other toggles.
my $filter_joins = 0; # 0 to display all joins as normal.
my $filter_parts = 0; # 0 to display all parts as normal.
my $filter_quits = 0; # 0 to display all quits as normal.
my $filter_modechanges = 0; # 0 to display all mode changes (both user and channel) as normal.
my $filter_nickchanges = 0; # 0 to display nick changes as normal.
my $filter_topicchanges = 0; # 0 to display topic changes as normal.
my $filters_showevent = 0; # 0 to just show generated info in spamtab. 1 to show the normal event message.
my $keep_config_in_dir = 1; # If set, will pre-pend the config's filename with the current config directory in Xchat. If 0 it won't mess with the filename at all.
##############################################
# End User Configuration Section. 
# Do not edit below here unless you're clever.
##############################################
my $script_name = 'Spamfilter';
my $script_ver = 'v.001';
Xchat::register( "Flashy's Myriad Scripts: $script_name", "$script_ver", "$script_name", "" );
my @spamarr=();
Xchat::hook_command('addspam', \&addspam); 
Xchat::hook_command('delspam', \&delspam); 
Xchat::hook_command('listspam', \&show_spamarr); 
Xchat::hook_command('showspam', \&show_spamarr); 
# Let's hook for traffic
Xchat::hook_print('Channel Message', \&checkit); # Check incoming text for triggers
Xchat::hook_print('Channel Action Hilight',\&checkit); # Check incoming text with my nick in it.
Xchat::hook_print('Channel Action',\&checkit); # Don't forget emotes
if ($filter_joins == 1) { Xchat::hook_print('Join',\&event_handler,{data=>'Join'}) };
if ($filter_parts == 1) { Xchat::hook_print('Part',\&event_handler,{data=>'Part'}) };
if ($filter_quits == 1) { Xchat::hook_print('Quit',\&event_handler,{data=>'Quit'}) };
if ($filter_modechanges == 1) { Xchat::hook_print('Raw Modes',\&event_handler,{data=>'Raw Modes'}) };
if ($filter_nickchanges == 1) { Xchat::hook_print('Change Nick',\&event_handler,{data=>'Change Nick'}) };
if ($filter_topicchanges == 1) { Xchat::hook_print('Topic Change',\&event_handler,{data=>'Topic Change'}) };
if ($filter_topicchanges == 1) { Xchat::hook_print('Channel Half-Operator',\&event_handler,{data=>'Channel Half-Operator'}) };
if ($filter_topicchanges == 1) { Xchat::hook_print('Channel Operator',\&event_handler,{data=>'Channel Operator'}) };
if ($filter_topicchanges == 1) { Xchat::hook_print('Channel Voice',\&event_handler,{data=>'Channel Voice'}) };
if ($filter_topicchanges == 1) { Xchat::hook_print('Channel DeOp',\&event_handler,{data=>'Channel DeOp'}) };
if ($filter_topicchanges == 1) { Xchat::hook_print('Channel DeVoice',\&event_handler,{data=>'Channel DeVoice'}) };
if ($filter_quits == 1) { Xchat::hook_print('Channel Mode Generic',\&event_handler,{data=>'Channel Mode Generic'}) };

if ($keep_config_in_dir == 1) { # Locate config in config directory
	my $tmp=Xchat::get_info('xchatdir') . '\\' . $spam_config;
	$spam_config = $tmp;
	}
load_config();
Xchat::print "\00304Flash's Script:\002 $script_name $script_ver (".scalar(@spamarr)." spam strings loaded)";
Xchat::print "($script_name adds \002/SHOWSPAM /ADDSPAM and /DELSPAM\002)";

# Only create the spam tab if it doesn't already exist to prevent creating multiples
if (! Xchat::find_context($spam_tab_name)) { Xchat::command("newserver -noconnect $spam_tab_name"); }

sub addspam { # Add a word to the spamfilter	
	my $line = $_[1][1];
	if ($line eq '') { Xchat::print("$script_name error: Usage: /addspam spam string"); return Xchat::EAT_ALL; }
	open (CF,">>$spam_config") or Xchat::print("$script_name error: Cannot open config file \"$spam_config\""); 
	print CF "$line\n";
	close(CF);
	push(@spamarr,$line);
	Xchat::print("$script_name: Added to spam strings: \"$line\"");
	return Xchat::EAT_XCHAT;
	}

sub load_config { # load spam strings to array from file	
	open(CF,"<$spam_config") or Xchat::print("$script_name error: Cannot open config file \"$spam_config\" - No Spam Strings loaded.");
	@spamarr=(); # empty buffer first
	my @tmparr;
	while (<CF>) {
		chomp;
		push (@spamarr,$_);
		}
	close(CF);
	}

sub show_spamarr { # display spam strings
	my $curcnt=0;
	if ($showlist_current_tab == 0) { spamit("\002$script_name listing spam strings (/ADDSPAM and /DELSPAM to edit)"); } else { Xchat::print("\002$script_name listing spam strings (/ADDSPAM and /DELSPAM to edit)"); } 
	foreach(@spamarr) {
		if ($showlist_current_tab eq 0) { spamit("$curcnt: $_"); } else { Xchat::print("$curcnt: $_"); }
		$curcnt++;
		}
	return Xchat::EAT_XCHAT;
	}

sub delspam { # Delete a string from the array, then save them. 	
	my $line = $_[1][1];
	if ($line eq '') { Xchat::print("$script_name error: Usage: /delspam spam string"); return Xchat::EAT_ALL; }
	Xchat::print("Removing line $line");
	my @newarr;
	my $cnt=0;
	my $fnd=0;
	foreach(@spamarr) {
		if ($line ne $cnt) { push(@newarr,$_); } else { $fnd++;  Xchat::print("Found entry $line, deleting ($_)"); }
		$cnt++;
		}
	Xchat::print("$script_name: $fnd spam strings removed.");
	@spamarr = @newarr;
	# Save config
	open (CF,">$spam_config") or Xchat::print("$script_name error: Cannot write to config file \"$spam_config\"");
	foreach(@spamarr) {
		print CF "$_\n";
		}
	close (CF);
	return Xchat::EAT_XCHAT;
	}

sub spamit { # Output string to spam tab
	my $line = shift;
	Xchat::set_context($spam_tab_name);
	Xchat::print($line);	
	}

sub checkit { # Scan channel message, highlights and emotes
	my $nick = $_[0][0];
	my $line = $_[0][1];
	my $chan = Xchat::get_info('channel');	
	if (grep { $chan eq $_ } @nofilter_chans) { return Xchat::EAT_NONE; } # It's in a channel we don't want filtered. Bail out.
	my $which=0;
	foreach(@spamarr) {
		if ($line =~ /\Q$_\E/i) {  #  In \Q\E to ensure exact match, no regex expansion
			if ($send_to_spam_tab == 1) { # Send to spamtab
				if ($spamtab_colours == 1) {
					spamit("$which: \003$spamtab_col_chan$chan \003$spamtab_col_nick$nick : \003$spamtab_col_spam$line");
					} else {
					spamit("$which: $chan $nick : $line");					
					}
				}
			return Xchat::EAT_XCHAT;
			}
		$which++;
		}
	}

sub event_handler { # Simply eat everything passed to it	
	my $nick = $_[0][0];
	my $event = $_[1];
	my $chan = Xchat::get_info('channel');	
	if (grep { $chan eq $_ } @nofilter_chans) { return Xchat::EAT_NONE; } # It's in a channel we don't want filtered. Bail out.
	if ($send_to_spam_tab == 1) { # Send to spamtab
		if ($filters_showevent == 0) {
			if ($spamtab_colours == 1) {			
				spamit("\003$spamtab_col_chan$chan \003$spamtab_col_event$event \003: \003$spamtab_col_nick$_[0][0] \003: \003$spamtab_col_spam$_[0][1] $_[0][2]");
				} else {
				spamit("$chan $event : $nick : $event");					
				}
			} else {
			Xchat::set_context($spam_tab_name);
			spamit("Following occured on $chan");
			Xchat::emit_print $event, @{$_[0]};
			}
		}
	return Xchat::EAT_XCHAT; 
	}