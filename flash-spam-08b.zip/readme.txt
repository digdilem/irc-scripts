Flash's X-Chat scripts:
        irc-flash@digdilem.org
        Flash_ at #3am irc.quakenet.org and #perl irc.oftn.net
        
Written on and for Windows's X-Chat versions, although should run fine on Linux too with
a small adjustment of the home path. (Nice to turn the tables on all the linux-only scripts
available for X-Chat... :x )  Works across multiple connected servers.

History:
0.8b - First release.
        1 known issue: If you are connected to multiple servers, the currently active tab
        will be the server that this tries to post to. Therefore I don't imply any support 
        for multiple servers with this version.

Short Description:

To do one or more of the following:
       1. Watch for the creation of a text file, then post the contents 
          of it to a specific chan, then delete it. Many purposes when used
          used with external programs. 
       2. Repeat a string to a specific chan at regular intervals.
       3. As 2, but picking string randomly from a text file. (Ie, random quotes)
       
Each function can run independantly of the others. Each function can be toggled on
or off from the command line (make some buttons too if you like!)

*** Do not ask me to add multiple channel support for these functions. I will NOT!     

*** Do not moan to me if you get kicked or banned for using this script. It is a 
        powerful script, understand what it does before you use it! If you annoy 
        others by using it, that is YOUR fault, not mine!


Detail of each function:

1. Textpost. (Posts text file direct to channel) "/textpost" to toggle.
Every five seconds, script checks for the existence of the named text file. 
If found, it simply blats the contents, unchanged, into your chosen channel and 
then DELETES the file. Intended for getting data from other programs - say a php
script on a website. Don't put anything important in this file that you won't miss
when it gets deleted. It won't be moved to your recycle bin, it'll just disappear, ok?
Also don't be trying binary files. I don't know what will happen but it's probably going
to be bad.

2. Single Post (Posts single string to a specific channel at regular intervals)
        "/singlepost" to toggle.
Simply posts the string in your config to the specific channel every n seconds.

3. Random Post (Posts random line from a text file to a specific channel at regular
        intervals.) "/randompost" to toggle.
Exactly the same as 2, except that instead of taking a string from the script, it will
grab it from a text file. It picks a random line (no support for multilines, linebreaks
etc) from that file. 

Tip: If you want to regularly post information that might change, instead of using Single 
Post, use Random Post but only have one line in your text file. Since that file is checked 
every time, it'll use what's there at the time it checks.



Installation:


0a. WINDOWS: YOU MUST HAVE THE PERL PLUGIN ENABLED AND PERL INSTALLED!
0b. LINUX: YOU MUST HAVE PERL INSTALLED!

1.
Copy the following files to your X-Chat's HOME directory. (The user's dir, not where you installed xchat)
        Under Windows XP - this dir is: "C:\Documents and Settings\YOUR_USER_NAME\Application Data\X-Chat 2". 
         When you find the right one you'll see a bunch of .conf files. You can quick-find by opening Logfiles 
         dir from Xchats prefs menu/logging and ascend one level. Note "Application Data" is set to HIDDEN by 
         default so you may not find it unless you enable hidden files in Explorer. 
         Yeah, I know - MS sucks, news at eleven. 
         Important: Under windows, X-chat still likes forward slashes to seperate directories like linux. Using
         Dos backslashes is likely to mean it can't find a file. Also escape spaces in filenames by prefixing with
         a backslash. 
        
        Under linux, it's "~/.xchat/" by default. 
        
        Flash-spam.pl   - The script
        quotes.txt     - An example list of one-per-line quotes. (Steven Wright quotes actually, this guy is ace :) )
        
2.
Edit Flash-spam.pl and change the fields you want to in the top section. The defaults are all OFF to prevent
you causing a nuisance with a half-configured script. Each function has its own group of configs, so change to suit
and read the comments which should explain which is which.


3.
Load script in Xchat. Either use "/load "full path"" or the nice little popup menu. By placing .pl files in this 
folder, they are automatically loaded by Xchat on startup, so you could just restart Xchat and it should load.


On Success, you will notice "Loading Flashy's Spam script" printed somewhere.