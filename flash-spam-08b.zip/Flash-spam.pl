#!/usr/bin/perl
#
# irc-flash@digdilem.org - poke Flash_ at irc.quakenet.org - #3am
# If used in your own work, please include my name in it somewhere, thanks.
# 12th March, 2005
#
# Flash-spam.pl   Purpose: To do one or more of the following:
#       1. Watch for the creation of a text file, then post the contents 
#          of it to a specific chan, then delete it. Many purposes when used
#          used with external programs. 
#       2. Repeat a string to a specific chan at regular intervals.
#       3. As 2, but picking string randomly from a text file. (Ie, random quotes)
#
# Do not ask me to change this script to post to multiple channels, that would be too 
# annoying. 
#
# Config: Change each section you wish to enable (all disabled by default)
#####################################################################################
# Global Config
# Print what's going on in current chan?
$flsp_global_print=0;
#####################################################################################
# Text-file posting details, change to suit.
# Enable or disable this feature? ( Toggle in-client with /textpost )
$flsp_textpost_on=0;  # 0 = off, 1 = on
#
# Textfile (including path) to look for: (Windows users! Use forward slashes in path!)
$flsp_textpost_file="c:/temp/postfile.txt";
#
# Channel to post this information in
$flsp_textpost_channel="#flashbots";
#
#####################################################################################
# Repeat single string function, change to suit.
# Enable or disable single-string posting? ( Toggle in-client with /singlepost )
$flsp_single_post=0;
#
# String to post
$flsp_single_string="I will post this string!";
#
# Channel to post to.
$flsp_single_channel="#flashbots";
#
# Interval (in seconds) between repeat postings. (86400 = once per day, 3600=Once per hour)
$flsp_single_interval="3600";
#
#####################################################################################
# Random repeat strings function, change to suit.
# Enable or disable random string posting?
$flsp_random_post=0;
#
# Path and filename of textfile containing quotes. (One per line!)
$flsp_random_file = "$ENV{'HOME'}/Application\ Data/X-Chat\ 2/quotes.txt";
#
# Channel to post to:
$flsp_random_channel="#3am";
#
# Interval (in seconds) between posts. (86400 = Once per day, 3600=Once per hour)
$flsp_random_interval="3600";
#
#####################################################################################
# End of user config, don't touch the rest unless you're a funky perl guru!
#####################################################################################
$flsp_debug=0; # Toggles debug mode
$flsp_version = "0.8a";
Xchat::register( "Flashy's Spam Script", "$flsp_version", "Timed postings", "" );
Xchat::print "Loading Flashy's Spam script $flsp_version ( /textpost /singlepost /randompost )";
if ($flsp_textpost_on) { Xchat::print"Spam status - Textpost   : On"; } else { Xchat::print"Spam status - Textpost   : Off"; }
if ($flsp_single_post) { Xchat::print"Spam status - Single Post: On"; } else { Xchat::print"Spam status - Single Post: Off"; }
if ($flsp_random_post) { Xchat::print"Spam status - Random Post: On"; } else { Xchat::print"Spam status - Random Post: Off"; }

# Textpost section
# Register timer first time, give default 5000 to check every five seconds
if ($flsp_textpost_on eq 1) { $flsp_tp_timer = Xchat::hook_timer(5000, flsp_textpost); }
# Register command hooks
IRC::add_command_handler("textpost", "flsp_textpost_toggle");
# Routine called every timer loop
sub flsp_textpost {
        if ($flsp_debug)        { Xchat::print "Debug: Textpost loop!"; }
        # Check for file:
        if (-e "$flsp_textpost_file") {                
                if ($flsp_global_print) { Xchat::print "Found file: $flsp_textpost_file -> Posting to $flsp_textpost_channel"; }
                # Read in and output each line in that file:
                open (SP, "<$flsp_textpost_file") or ( Xchat::print"Error! Cannot open file for reading: flsp_textpost_file" );
                @flsp = <SP>;
                close (SP);
                foreach (@flsp) {
                        chomp;
                        if ($flsp_debug) { Xchat::print"Debug: Read Line: $_"; }
                        IRC::command("/MSG $flsp_textpost_channel $_");
                        }
                # Now remove file
                unlink("$flsp_textpost_file");
                }
        
        if ($flsp_textpost_on) { # Check it hasn't been turned off        
                Xchat::unhook($flsp_tp_timer); # Kill existing timer
                $flsp_tp_timer = Xchat::hook_timer(5000, flsp_textpost);
                }
}
# Toggle textpost through command
sub flsp_textpost_toggle {
        if ($flsp_textpost_on) {
                $flsp_textpost_on=0;
                Xchat::unhook($flsp_tp_timer); # Kill existing timer
                Xchat::print"Spam Textpost script disabled";
                } else {
                $flsp_textpost_on=1;
                $flsp_tp_timer = Xchat::hook_timer(5000, flsp_textpost);
                Xchat::print"Spam Textpost script enabled";    
                }
        
        }
        
######################
# Single Post Section
$flsp_single_interval_sec = ($flsp_single_interval * 1000);
if ($flsp_single_post) { 
        $flsp_sp_timer = Xchat::hook_timer($flsp_single_interval_sec, flsp_single_interval); 
        flsp_single_interval();
        }
# Register command hooks
IRC::add_command_handler("singlepost", "flsp_singlepost_toggle");

sub flsp_single_interval {
        if ($flsp_debug) { Xchat::print "Spam Single Post (Id: $flsp_sp_timer)"; }        
        IRC::command("/MSG $flsp_single_channel $flsp_single_string");   
        
        Xchat::unhook($flsp_sp_timer); # Kill existing timer
        if ($flsp_single_post) { $flsp_sp_timer = Xchat::hook_timer($flsp_single_interval_sec, flsp_single_interval); }
        }

sub flsp_singlepost_toggle {
        if ($flsp_single_post) {
                Xchat::print"Spam Single Post Disabled";
                $flsp_single_post=0;
                Xchat::unhook($flsp_sp_timer); # Kill existing timer
                } else {
                Xchat::print"Spam Single Post Enabled";
                $flsp_single_post=1;
                $flsp_sp_timer = Xchat::hook_timer($flsp_single_interval_sec, flsp_single_interval); 
                }
        }
        
        
######################
# Random Post Section
$flsp_random_interval_sec = ($flsp_random_interval * 1000);
if ($flsp_random_post) { 
        $flsp_sp_timer = Xchat::hook_timer($flsp_random_interval_sec, flsp_random_interval); 
        flsp_random_interval();
        }
# Register command hooks
IRC::add_command_handler("randompost", "flsp_randompost_toggle");

sub flsp_random_interval {
        if ($flsp_debug) { Xchat::print "Spam Single Post (Id: $flsp_sp_timer)"; }   
        # Pick random string from file
        open (RF, "<$flsp_random_file") or (Xchat::print"Cannot open Random Spams file: $flsp_random_file" );
        rand($.) < 1 && ($flsp_rand_line = $_) while <RF>; # Pick random line
        close(RF);
        chomp($flsp_rand_line);             
        IRC::command("/MSG $flsp_random_channel $flsp_rand_line");   
        Xchat::unhook($flsp_sp_timer); # Kill existing timer
        if ($flsp_random_post) { $flsp_sp_timer = Xchat::hook_timer($flsp_random_interval_sec, flsp_random_interval); }
        }

sub flsp_randompost_toggle {
        if ($flsp_random_post) {
                Xchat::print"Spam Random Post Disabled";
                $flsp_random_post=0;
                Xchat::unhook($flsp_sp_timer); # Kill existing timer
                } else {
                Xchat::print"Spam Random Post Enabled";
                $flsp_random_post=1;
                $flsp_sp_timer = Xchat::hook_timer($flsp_random_interval_sec, flsp_random_interval); 
                }
        }