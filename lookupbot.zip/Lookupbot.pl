#!perl -T
# Original by Craig Andrews for IRSSI
# Hacked to work with Xchat by Flash_  25-May-06
#
# To use - copy to your xchat scripts directory and /reloadall.
# Note: There will be a short pause on responding while this script connects to the relevant websites and gets the info. Don't panic!
#
# Adds the following commands:
#
# !dict string = Searches Dictionary.com for a definition of string. Eg: !dict banana
# !image string = Searches images.google.com for an image matching string and returns the url. Eg: !image bananas
# !urban string = Searches urbandictionary.com for "alternative" definitions. Eg: !urban flute (Warning - Content may be offensive)
# !profan string = Searches vic.co.uk's Profanisauris. Eg: !urban {UseYourImagination}  (Warning - Almost certain to offend)
# !thes string =  Searches thesaurus.com for alternative meanings to words. Eg: !thes apple (Warning - Can be a bit poetic) 
# !define string = Searches Google for definitions. Eg: !define word
#
# Also you can return multiple hits. !image 3 string will return the first 3 hits instead of just the first one.

use strict;
# use Irssi;
use LWP::Simple;
use LWP::UserAgent;
use CGI qw/unescapeHTML/;
use vars qw($VERSION %IRSSI);

my @lookup_badchannels=("#griblet","#truff"); # List of channels NOT to trigger in

$VERSION = '0.0.1x';


Xchat::register( "Craig Andrews lookupbot V.$VERSION (Converted by Flash_)", $VERSION, "lookupbot", "" );

Xchat::print("Loaded Craig Andrews lookupbot V.$VERSION (Converted by Flash_) - adds !profan, !urban, !dict, !thes, !image and !define");

#    'description' => 'Some kind of magical internet searcher',
#    'license' => 'Craig\'s Magical Freebie License');

# Get the count and cleaned up data
sub get_data {
    my $data = shift;

    my @params = split / +/, $data;
    my $trigger = shift @params;

    my $count = 1;
    if (defined $params[0] && int($params[0]) > 0) {
        $count = shift @params;
        $count = 10 if $count > 10;
    }

    $data = join ' ', @params;
    $data =~ s/[^[:print:]]/ /g;
    $data =~ s/  */ /g;

    return ($trigger, $count, $data);
}

# Retrieve the content froma url
sub get_content {
    my ($url, $data) = @_;

    $data = CGI::escape($data);
    $url = sprintf($url, $data) if defined $data;

    my $ua = LWP::UserAgent->new(agent => "google suck");
    my $result = $ua->get($url);

    my $content;
    $content = $result->content if $result->is_success;

    return $content;
}

sub image_search {
    my $content = shift;

    my @definitions = $content =~ /imgurl=(.+?)\&/g;

    return @definitions;
}

sub define_search {
    my $content = shift;

    $content =~ s/[\n\r]+/ /g;
    my @definitions = $content =~ /(?<=<li>)(.+?)(?=<br>|<li>)/ig;

    return @definitions;
}

sub dict_search {
    my $content = shift;

    $content =~ s/[\n\r]+/ /g;
    $content = '' if $content =~ /No entry found for/;
    $content =~ s/[^[:print:]]//g;
    $content =~ s/^(.*?)(?=entr(y|ies) found for)//;
    $content =~ s/(.*?)<\/table>/$1/ig;
    $content =~ s/<\/?CITE>/"/g;

    my @definitions;
    if ($content =~ /^entry/) {
        my @tmp = $content =~ /<p>(.+?)<\/p>/ig;
        @definitions[0] = @tmp[1];
    } else {
        @definitions = $content =~ /(?<=<li>|<dd>)(.+?)(?=<br>|<li>|<\/li>|<\/dd>)/ig;
    }

    return @definitions;
}

sub thes_search {
    my $content = shift;

    my @lines = split /\n/, $content;
    @lines = grep { /(Main Entry|Synonyms|Antonyms):/ } @lines;

    my @definitions;
    foreach (@lines) {
        s/^(.*?)<b>/ /;
        s/<\/b>(.*?)<td(.*?)>/ /g;
        s/<\/td>.*$/ /;

        if (/Main Entry:/ || scalar(@definitions) == 0) {
            push @definitions, $_;
        } else {
            $definitions[@definitions - 1] .= "\n$_";
        }
    }

    return @definitions;
}

sub urban_search {
    my $content = shift;

    $content =~ s/[\n\r]+/ /g;
    $content = '' if $content =~ /is undefined/;
    $content =~ s/[^[:print:]]//g;
    my @lines = $content =~ /<div class="(def_p)">(.+?)<div class="tags">/ig;

    my @definitions;
    my $ix;
    for ($ix = 0; $ix < @lines; $ix++) {
        my $line = $lines[$ix];
        unless ($line =~ /def_p/) {
            $line =~ s/<\/p>/\n/g;
            push @definitions, $line;
        }
    }

    return @definitions;
}

sub profan_search {
    my $content = shift;

    my @matches = $content =~ /<a href="(profan_results.php\?profan=searchstory.+?)">(.+?)</gsi;
    return '' unless @matches;

    my %definitions;
    my $ix;
    for ($ix = 0; $ix < @matches; $ix+=2) {
        my $key = $matches[$ix+1];
        $key =~ tr/A-Z/a-z/;
        $definitions{$key} = $matches[$ix];
    }

    my @keys = sort keys %definitions;

    $content = get_content('http://www.viz.co.uk/profanisaurus/'.$definitions{$keys[0]});
    @matches = $content =~ /class=profandefinition>(.+)/;

    return join "\n", @matches;
}

###
# Many different lookerupperers
###

my %ENGINES = ('!image' => {'url' => 'http://images.google.co.uk/images?hl=en&q=%s',
                            'sub' => \&image_search},
               '!define' => {'url' => 'http://www.google.co.uk/search?hl=en&q=define%%3A%%20%s',
                             'sub' => \&define_search},
               '!dict' => {'url' => 'http://www.dictionary.com/search?q=%s',
                           'sub' => \&dict_search},
               '!thes' => {'url' => 'http://www.thesaurus.com/search?q=%s',
                           'sub' => \&thes_search},
               '!urban' => {'url' => 'http://www.urbandictionary.com/define.php?term=%s',
                            'sub' => \&urban_search},
               '!profan' => {'url' => 'http://www.viz.co.uk/profanisaurus/profan_results.php?profan=search&prof_search=%s',
                            'sub' => \&profan_search});

# !stuff
sub public_responder {
#    my ($server, $data, $nick, $mask, $target) = @_;
	my $data = $_[0][1];
	my $nick = $_[0][0];
	$data =~ s/`//gosm;
	my $channel = Xchat::get_info('channel'); 
	# Check it's not a bad channel	
	foreach(@lookup_badchannels) {
		if ($channel eq $_) { return Xchat::EAT_NONE; } # Abort
		}

    my ($trigger, $count, $term) = get_data($data);

    my @definitions;
    my $found = 0;
    my $func;
    for $func (keys %ENGINES) {
        next unless $trigger eq $func;
        $found = 1;

        my $url = $ENGINES{$func}->{'url'};
        my $sub = $ENGINES{$func}->{'sub'};

        my $content = get_content($url, $term);
        @definitions = &{$sub}($content) if defined $content;
    }

# Quit if this isn't for us
    return unless $found == 1;

# Display if necessary
    if (defined @definitions && scalar(@definitions) > 0) {
        for (my $ix = 0; $ix < @definitions && $ix < $count; $ix++) {
            my @lines = split /\n/, $definitions[$ix];

            my $text;
            foreach $text (@lines) {
                next if $text =~ /^\s*$/;

# Strip HTML
                $text =~ s/<(.*?)>/ /g;
                $text = unescapeHTML($text);

# Strip non-printable characters
                $text =~ s/[^[:print:]]/ /g;

# Sort out whitespace
                $text =~ s/ +/ /g;
                $text =~ s/^ *//;
                $text =~ s/ *$//;

# And display
                Xchat::command("say -!- $text");
            }
        }
    } else {
        Xchat::command("say -!- No results found");
    }


}


#Irssi::signal_add("message public", \&public_responder);


Xchat::hook_print('Channel Message', "public_responder");
Xchat::hook_print('Your Message', "public_responder");

