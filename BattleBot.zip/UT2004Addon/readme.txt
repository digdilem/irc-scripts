If you're trying to install BattleBot, go to the \BattleBot\ folder of the .zip and open Readme.rtf


---------
UT2004Addon for BattleBot
By Motig
---------


Refer to the readme that came with BattleBot for info on how to set up the addon.

The command that you need to set your server IP's to in addons.ini is 'ut2004addon'.

For the script to work, the webadmin skin for each server must be set to the default skin (as it reads the webpages).

Also, as the script accesses webadmin, you need to supply a username/password for each server in ut2004addon.ini. An example has been given in that file.

Finally, to load the addon, go into mIRC and type /load -rs followed by the full path of the file UT2004addon.mrc in quotes; i.e:

/load -rs "C:\mIRC\BattleBot\UT2004Addon\UT2004addon.mrc"

It should now give some simple information when someone uses the !server command with the bot.