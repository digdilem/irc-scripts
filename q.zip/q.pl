#!/usr/bin/perl
#
# Flashy's Q Authing script for Quakenet. http://digdilem.org/
#
# Instructions: Change Q_auth_name and Q_auth_pass to your Q user/pass. Stick in your Xchat script directory and job's done.
# Script will attempt to auth with Q on first server join. 
# It will also check every $check_intervals milliseconds that it is authed and re-auth if not.
#
# Config Section
 
my $Q_auth_name = "USERNAME"; # Your Q AuthName
my $Q_auth_pass = "PASSWORD"; # Your Q Password
my $recheck = 0; # Whether to periodically check you're still authed. (Netsplits and bouncers can de-auth you)
					# NOTE! Enabling this results in ALL Q chat being hidden from you!
my $modex = 1; # Whether to hide your IP/hostname from whois once authed. 1 = yes, 0=no.
my $attempts=3; # Number of failed attempts to auth before giving up.
my $check_intervals = 50000; # milliseconds between auth attempts and checks. 300000 = 5 minutes, 600000=10 minutes. 1800000=30 mins.
#
# End Config
#
# Startup registers
Xchat::register( "Flashy's Q Authing Script", "V.001", "Q_Auther", "" );
Xchat::hook_print( "Server Text", "qserver_watch"); # Watch for server messages for initial run.
Xchat::hook_print("Notice","qchat_watch"); # Hook Q's replies
my $check_timer;
my $cur_attempt=0;

Xchat::print("Flashy's Q Authing script loaded.");

if ($recheck == 1) { 
	$check_timer=Xchat::hook_timer(50000,"check_qauth");
	check_qauth(); 
}

sub qserver_watch { # Called on messages from server. Tends not to work too well with bouncers.
	$qline = $_[0][0];
	if ($qline =~ /Welcome to the QuakeNet/) { # Change this is Qnet change their welcome string
			Xchat::print("Found Quakenet connection string, attempting auto-auth for $Q_auth_name");
			auth();
			# Also add a +x to hide the IP (On quakenet this replaces your hostmask with *@authname.quakenet.org.
			# Comment following line if for some insane reason you don't want that.
			if ($modex == 1) { Xchat::command("umode +x"); }
			}
return Xchat::EAT_NONE; 
}

sub qchat_watch {	
	$qline = $_[0][1];
	# Auth check
	if ($recheck == 1) {
			if ($qline =~ /You have authed as/ ) {
#			Xchat::print("Received auth confirmation from Q");
			$cur_attempt=0; # Reset counter as we're now authed.
			} 
			if($qline =~ /You have NOT authed/ ) {
				$cur_attempt++;
				Xchat::print("Warning: Q Authorisation has failed, retrying. Attempt $cur_attempt/$attempts... (q.pl)");
				auth();
				}
		if ($recheck == 1) {
			return Xchat::EAT_ALL; # Have to hide Q's notices or it'll spam the current chan. 
			} else { return Xchat::EAT_NONE; }
		}
}

sub check_qauth {
	Xchat::command("msg Q\@CServe.quakenet.org whoami");
	if ($cur_attempt+1 >= $attempts) { 
		Xchat::print("Error: Auth attempt " . $cur_attempt+1 . " exceeds max attempts $attempts. Final attempt."); 
		return Xchat::REMOVE; 
		} else {	
		return Xchat::KEEP; 
		}
}

sub auth {
	Xchat::command("msg Q\@CServe.quakenet.org auth $Q_auth_name $Q_auth_pass");
}
