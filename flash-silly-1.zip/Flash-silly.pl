#!/usr/bin/perl
#
# Flash-Silly.pl - Various "Silly" things for X-chat (Windows or Linux)
# Warning: If you use this and end up being kicked out of your favourite
# channel, it's your own damn fool fault! 
#
# Check "Readme" to see how to install this thing.
#
# The following silly things are added
##########################################################################
#       What you type         What others type (If triggers are ON)
##########################################################################
#       "/silly"                                        - Lists the functions added
#       "/silly_toggle"                                 - Toggles sillies on or off
#       "/remove_silly_buttons"                         - Remove silly buttons...
#       "/add_silly_buttons"                            - Add silly buttons...
#       "/gaymeter Nick"      !gaymeter nick            - Show gay-meter
#       "/hugometer Nick"     !hugometer nick           - Shows huggometer
#       "/kissometer Nick"    !kissometer nick          - Kiss somebody
#       "/lameometer Nick"    !lameometer nick          - Show how lame somebody is...
#       "/lovemeter Nick"     !lovemeter nick nick      - How much do you love $nick ?
#       
#       "/bunny"              !bunny                    - Prints a cute bunny
#       "/teddy"              !teddy                    - Prints a teddy bear...
#       "/penguin"            !penguin                  - Prints a liddle penguin
#
# Do you want loads of extra buttons added?
# These appear below your userlist and might be too much. Change the following to 
# 0 to disable, and/or use /remove_silly_buttons and /add_silly_buttons to toggle
# them without reloading script.
#
$fl_silly_buttons=1;
#
# Do you want others to be able to trigger events remotely? (Ie, force you to do things...)
# If people abuse this, you can always temporarily disable your responses with /silly_toggle
#
$fl_silly_triggers=1;
#
# That's it, no more configuration needed.
##########################################################################
# Don't be touching this stuff below here unless yer a genius, k?
#
# Register stuff and global vars
$flsil_version="1";
$flsil_toggle="1";      # Toggle entire sillies
$flsil_roll;
$meter_string1 = "";
Xchat::register( "Flashy's Silly Script", "$flsil_version", "Silly things", "" );
Xchat::print "Loading Flashy's Silly Script v.$flsil_version ( /silly )";
IRC::add_message_handler("PRIVMSG", "watch_sillytriggers");
srand;

# Commands
IRC::add_command_handler("gayometer", "gayometer");
IRC::add_command_handler("hugometer", "hugometer");
IRC::add_command_handler("kissometer", "kissometer");
IRC::add_command_handler("lameometer", "lameometer");
IRC::add_command_handler("lovemeter", "lovemeter");
IRC::add_command_handler("bunny", "print_bunny");
IRC::add_command_handler("teddy", "print_teddy");
IRC::add_command_handler("penguin", "print_penguin");
# Control commands
IRC::add_command_handler("silly", "silly_list");
IRC::add_command_handler("silly_toggle", "silly_toggle");
IRC::add_command_handler("remove_silly_buttons","remove_silly_buttons");
IRC::add_command_handler("add_silly_buttons","add_silly_buttons");
# Remote triggers

sub gayometer {
        if ($flsil_toggle) {
                meters();                
                IRC::command("/say Gay-O-Meter! $_[0] is $meter_string1 gay!");
                return 1;
        }
}
sub hugometer {
        if ($flsil_toggle) {
                meters();
                IRC::command("/say Hug-O-Meter! $_[0] is $meter_string1 huggable!");
                return 1;
        }
}
sub kissometer {
        if ($flsil_toggle) {
                meters();
                IRC::command("/say Kiss-O-Meter! $_[0] is $meter_string1 kissable!");
                return 1;
        }
}
sub lameometer {
        if ($flsil_toggle) {
                meters();
                IRC::command("/say Lame-O-Meter! $_[0] is $meter_string1 lame!");
                return 1;
        }
}
sub lovemeter {
        if ($flsil_toggle) {
                meters();
                $mynick = IRC::get_info(1);
                IRC::command("/say Love-Meter! $_[0] loves $mynick $meter_string1!");
                return 1;
        }
}

sub print_bunny {
        if ($flsil_toggle) {
                IRC::command("/say    _   _ ");
                IRC::command("/say   ( \\_/ )");
                IRC::command("/say  (=^_^=)");
                IRC::command("/say   (-)_(-)");   
                return 1;
        }
}

sub print_teddy {       
        if ($flsil_toggle) {
                IRC::command("/say  {~._.~}");
                IRC::command("/say  _( Y )_");
                IRC::command("/say  ()~*~()");
                IRC::command("/say  (_)-(_)");
                return 1;
        }
}
sub print_penguin {       
        if ($flsil_toggle) {
                IRC::command("/say  (o_  ");
                IRC::command("/say //\\ ");
                IRC::command("/say V_/_ ");
                return 1;
        }
}

sub silly_list {
        IRC::print "Flash's Silly commands:";
        IRC::print "-----------------------";
        IRC::print "      /silly_toggle";
        IRC::print "      /remove_silly_buttons";
        IRC::print "      /add_silly_buttons";
        IRC::print "-----------------------";
        IRC::print "      /gayometer";
        IRC::print "      /hugometer";
        IRC::print "      /kissometer";
        IRC::print "      /lameometer";
        IRC::print "      /lovemeter";
        IRC::print "      /bunny";
        IRC::print "      /teddy";        
        IRC::print "      /penguin";        
        IRC::print "-----------------------";
        return 1;        
}

sub silly_toggle {
        if ($flsil_toggle) {
                IRC::print "Flash's Sillies are now OFF!";
                $flsil_toggle=0;
        } else {
                IRC::print "Flash's Sillies are now ON!";
                $flsil_toggle=1;
        }
}

sub meters {    # Stuff meter strings with random values
        $flsil_roll = int(rand 10) + 1; # random number between 1 and 10
        $meter_string1 = "[";
        for ($a = 0; $a != $flsil_roll; $a++) { $meter_string1 .= "#"; }
        for ($a = $flsil_roll; $a != 10; $a++) { $meter_string1 .= " . "; }  # Fill rest with -
        $flsil_perc = ($flsil_roll * 10);  # Give rounded percent figure, nicer.
        $meter_string1 .= "] $flsil_perc%";
}

if ($fl_silly_buttons) {  # Add masses of buttons! OMG THERE ARE TOO MANY!  
        
        remove_silly_buttons();  # So we don't add a double set
        add_silly_buttons();
}

sub remove_silly_buttons {
        IRC::command "/delbutton Sillies";
        IRC::command "/delbutton Gayometer";
        IRC::command "/delbutton Kissometer";
        IRC::command "/delbutton Hugometer";
        IRC::command "/delbutton Lameometer";
        IRC::command "/delbutton Lovemeter";
        IRC::command "/delbutton Bunny";
        IRC::command "/delbutton Teddy";   
        IRC::command "/delbutton Penguin";
}

sub add_silly_buttons {
        IRC::command "/addbutton Sillies silly_toggle %s";
        IRC::command "/addbutton Gayometer gayometer %s";
        IRC::command "/addbutton Kissometer kissometer %s";  
        IRC::command "/addbutton Hugometer hugometer %s";
        IRC::command "/addbutton Lameometer lameometer %s";  
        IRC::command "/addbutton Lovemeter lovemeter %s";    
        IRC::command "/addbutton Bunny bunny";  
        IRC::command "/addbutton Teddy teddy";   
        IRC::command "/addbutton Penguin penguin";
}

sub watch_sillytriggers {
       if ($fl_silly_triggers) {
               foreach $line (@_) {
                        $line =~ m/\:(.*?)\!(.*?)\sPRIVMSG\s(.*?)\s\:(.*)?/;
                                       
                        $m_nick = $1;
                        $m_send = $2;
                        $m_chan = $3;
                        $m_line = $4;
                                       
                        $m_line =~ s/^\s+//; # Remove trailing whitespace
                        $m_line =~ s/\s+$//;
                        
                        if ($m_line =~ m/!gayometer/gi) { gayometer($m_nick); }
                        if ($m_line =~ m/!hugometer/gi) { hugometer($m_nick); }
                        if ($m_line =~ m/!kissometer/gi) { kissometer($m_nick); }
                        if ($m_line =~ m/!lameometer/gi) { lameometer($m_nick); }
                        if ($m_line =~ m/!lovemeter/gi) { lovemeter($m_nick); }
                        if ($m_line =~ m/!bunny/gi) { print_bunny($m_nick); }
                        if ($m_line =~ m/!teddy/gi) { print_teddy($m_nick); }
                        if ($m_line =~ m/!penguin/gi) { print_penguin($m_nick); }
                        }
       }
}