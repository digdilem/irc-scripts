Flash's X-Chat scripts:      irc-flash@digdilem.org     Flash_ at #3am irc.quakenet.org and #perl irc.oftn.net        
        Written on and for Windows's X-Chat versions 2.4.x, although should run fine on Linux too.
        
Short Description:

Adds a whole bunch of silly stuff.


#       What you type         What others type (If triggers are ON)
##########################################################################
#       "/silly"                                        - Lists the functions added
#       "/silly_toggle"                                 - Toggles sillies on or off
#       "/remove_silly_buttons"                         - Remove silly buttons...
#       "/add_silly_buttons"                            - Add silly buttons...
#       "/gaymeter Nick"      !gaymeter nick            - Show gay-meter
#       "/hugometer Nick"     !hugometer nick           - Shows huggometer
#       "/kissometer Nick"    !kissometer nick          - Kiss somebody
#       "/lameometer Nick"    !lameometer nick          - Show how lame somebody is...
#       "/lovemeter Nick"     !lovemeter nick nick      - How much do you love $nick ?
#       
#       "/bunny"              !bunny                    - Prints a cute bunny
#       "/teddy"              !teddy                    - Prints a teddy bear...
#       "/penguin"            !penguin                  - Prints a liddle penguin
        
        
Installation:

0a. WINDOWS: YOU MUST HAVE THE PERL PLUGIN ENABLED AND PERL INSTALLED!
0b. LINUX: YOU MUST HAVE PERL INSTALLED!

1.
Copy the following file to your X-Chat's HOME directory. (The user's dir, not where you installed xchat)
        Under Windows XP - this dir is: "C:\Documents and Settings\YOUR_USER_NAME\Application Data\X-Chat 2". 
         When you find the right one you'll see a bunch of .conf files. You can quick-find by opening Logfiles 
         dir from Xchats prefs menu/logging and ascend one level. Note "Application Data" is set to HIDDEN by 
         default so you may not find it unless you enable hidden files in Explorer. 
         Yeah, I know - MS sucks, news at eleven.
        
        Under linux, it's "~/.xchat/" by default. 
        
        Flash-silly.pl   - The script
        
2.
Load script in Xchat. Either use "/load "full path"" or the nice little popup menu. By placing .pl files in xchat's 
user home folder, they are automatically loaded by Xchat on startup, so you could just restart Xchat and it should load.

On Success, you will notice "Loading Flashy's Silly Script" printed somewhere, and (unless you disabled them), a whole bunch of new buttons under the userlist. Select a user and click a button. (Not all require a user) 
You can select multiple users for mega-spam too, using ctrl + click on the userlist prior to hitting the button. You can just type the /command above manually if you like. The remote triggers won't work if you type 'em, they need to come
from someone else... (That's why you have buttons)

You can add these to a popup menu too, but Xchat doesn't appear to let me do that automatically, sorry!