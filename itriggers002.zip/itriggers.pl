#!/usr/bin/perl
# Install? Put this one in ~/.irssi/scripts/autorun and triggers.txt in ~/.irssi - or change the $triggerfile below
# Upgrade? Copy only this file over the existing itriggers.pl but don't overwrite your existing triggers.txt file or you'll lose your stuff.
#	Upgrades are backwards compatible with existing trigger files.
#
# Flashy's script. digdilem.org - poke Flash_ at irc.quakenet.org - #truff
# "A lightweight trigger / responder script"
# If used in your own work, please include my name in it somewhere, thanks.
#
# Trigger script. Reads triggers in from textfile and responds for you when those
# triggers are called in channel.
# Toggle off/on with "/trigger" (Default is ON when script loads)
# March 2008 - Converted by the author from my original Xchat script.
# History:
# i001 - Initial rewrite for irssi
#		 Added /trigger add|del commands to make it easier to add/remove them.
# i002 - Added %file:% trigger to allow quotes to be added mid-reply. Allows the like of !stig to pick two random lines and present them in the same reply
#	   - Fixed %m %s %u and %t
#
# Macros supported (In replies, and some in triggers too):
# %n = Nick of person invoking trigger
# %c = Channel
# %m = My Nick
# %s = Server Tag
# %t = Channel topic
# %u = Random person from the channel.
# %l = Original line.
# %1 = First word of original line
# %2 = Second word of original line
# %3 = Third word of original line
# %file:FILENAME% = Pick random line from FILENAME. Eg: !stig|*|say Some say %file:stig.txt% and %file:stig.txt%. All we know is, he's called the Stig.
#
use strict;
###################################################################################
# Start user configuration
###################################################################################
# Where is the trigger file?
my $triggerfile = "triggers.txt";
# List of channels NOT to trigger on (In quotes, seperated by commas eg "#chan1","#chan2")
# Ie, very busy ones where your triggers may be annoying, or very very busy ones where checking each line can lead to high cpu usage.
my @fltr_nothesechans = ("#channel1");
#
###################################################################################
# End user configuration
###################################################################################
use vars qw($VERSION %IRSSI);
use Irssi;
$VERSION = 'i002';
%IRSSI = (
    authors     => 'Flash',
    contact     => 'flash@multiplay.co.uk',
    name        => 'iTriggers',
    description => 'Replies to stuff automatically ',
    license     => 'Do what thou wilt.',
);
Irssi::signal_add("message public", \&watch_triggers);
Irssi::command_bind('trigger', 'trigger');

my $fltr_debug = 0; # Set debug info
my @FLTF; # Main array holding config

my $fl_tr_size = ( -s $triggerfile);
load_triggers();

sub load_triggers {
	$fl_tr_size = (-s $triggerfile);
	open (TF, "<$triggerfile"); # Don't warn if not there
	@FLTF = <TF>;
	close(TF);
	}

sub watch_triggers {  # Called every time a message is put to a chan you are in
    my ($server, $m_line, $m_nick, $mask, $m_chan) = @_;
	if ($fl_tr_size ne (-s $triggerfile)) { print "Triggers filesize changed, reloading"; load_triggers(); } #Triggerlist has changed, reload

	my $chanrec = $server->channel_find($m_chan);
	my $fltr_mynick = $server->{'nick'};
	my $fltr_server = $server->{'tag'};
	my $fltr_topic = $chanrec->{'topic'};

	$m_line =~ s/^\s+//; # Remove trailing whitespace
	$m_line =~ s/\s+$//;
	if ($fltr_debug == 1) { print "Received: [($server, $m_line, $m_nick, $mask, $m_chan)]"; }

	# Check to see whether this channel is an excluded one
	foreach(@fltr_nothesechans) {
		if (lc($m_chan) eq lc($_)) {
			if ($fltr_debug) { print"Channel $m_chan matches chan $_ in exclude list, stopping right here."; }
			return;
		}
		foreach(@FLTF) {
			my $fltr_first = substr($_,0,1);
			if ($fltr_first ne '#') { # Ignore commented lines
				$_ =~ chomp;
				my ($t_trig,$t_chan,$t_data) = split(/\|/,$_);
				$t_trig =~ s/%n/$m_nick/gi;
				$t_trig =~ s/%m/$fltr_mynick/gi;
				$t_trig =~ s/%c/$m_chan/gi;
				$t_trig =~ s/%s/$fltr_server/gi;
				$t_trig =~ s/%t/$fltr_topic/gi;
				$t_trig =~ s/%l/$m_line/gi;
				# Check each config entry for correct channel, or "ALL"
				if ((lc($m_chan) eq lc($t_chan)) or (lc($t_chan) =~ /\*/)) {   # And we're off!
					# Now check to see if trigger matches
					if (lc($m_line) =~ /$t_trig/i) { # Check to see whether it contains partial trigger !
						my @split_line = split(/ /,$m_line);
						# Add stuff to parse responds
						my $t_resp = $t_data;
						$t_resp =~ s/%n/$m_nick/gi;
						$t_resp =~ s/%c/$m_chan/gi;
						$t_resp =~ s/%m/$fltr_mynick/gi;
						$t_resp =~ s/%s/$fltr_server/gi;
						$t_resp =~ s/%t/$fltr_topic/gi;
#						$t_resp =~ s/%u/@users[rand int(@users)]/gi;  # Picks random user from channel
						$t_resp =~ s/%u/my @users = map { $_->{'nick'} } $chanrec->nicks(); @users[rand int(@users)]/gie;  # Picks random user from channel
						$t_resp =~ s/%l/$m_line/gi;
						$t_resp =~ s/%1/@split_line[0]/gi;
						$t_resp =~ s/%2/@split_line[1]/gi;
						$t_resp =~ s/%3/@split_line[2]/gi;
						# Kkludgey stuff to check for a quote
						if ($t_resp =~ /^quote /i) {
							my @qsplit = split(/ /,$t_resp);
							$t_resp = "say ".getquote(@qsplit[1]);
							}
						# Same again for coloursay
						if ($t_resp =~ /^coloursay /i) {
							my @qsplit = split(/ /,$t_resp);
							$t_resp = "say ".coloursay(join ' ', @qsplit[1 .. @qsplit]);
							}
						while ($t_resp =~ m/%file:(.+?)%/g) { # Add a random line from a file
							print "AWOOGA: I found filename '$1'";
							$t_resp =~ s/%file:(.+?)%/getquote($1)/e;
							}
						my $context = undef;
						if (defined($server)) {
									if (defined($m_chan) && $server->channel_find($m_chan)) {
										$context = $server->channel_find($m_chan);
									} else {
										$context = $server;
									}
								} else {
									$context = undef;
								}
						if (defined($context)) {
									$context->command("eval $t_resp");
								} else {
									Irssi::command("eval $t_resp");
								}
						}
				}
			}
		}
	}
}
sub trigger {
    my ($data, $server, $witem) = @_;
	$data =~ s/\|/:/g; # remove any pipes
	my @arr = split (/ /,$data);
	my $known = 0;
	if (lc($arr[0] eq 'add')) {  # /trigger add !trigger Channel Response
		if (!defined $arr[3]) { print "Usage; /trigger add !trigger channel/* Response"; return; }
		my $action = join ' ', @arr[3 .. @arr];
		chop($action);
		print "Adding trigger \"$arr[1]\" in channel \"$arr[2]\" with action \"$action\"";
		open(OF,">>$triggerfile") or print("Error - cannot open file $triggerfile");
		print OF "$arr[1]|$arr[2]|$action\n";
		close(OF);
		load_triggers();
		$known = 1;
		}
	if (lc($arr[0] eq 'del')) {
		if (!defined $arr[1]) { print "Usage; /trigger del !trigger"; return; }
		my $found=0;
		open(IF,"<$triggerfile");
		my @ncf;
		my $lines=0;
		while(<IF>) {
			my @words = split(/\|/);
			if (lc($words[0] eq $arr[1])) { $found++; print "Deleting $found instance of \"$arr[1]\""; } else { push(@ncf,$_); }
			$lines++;
			}
		close(IF);
		if ($found != 0) {
			open(OF,">$triggerfile");
			foreach (@ncf) { print OF $_; }
			close(OF);
			} else { print "Sorry, couldn't find any triggers matching \"$arr[1]\" in $lines lines of $triggerfile"; }
		$known=1;
		}
	if ($known == 0) { print "Sorry, I don't know the command \"$arr[0]\" - usage: /trigger add|del"; }
	}

sub getquote {
	my $quotefile = shift;
	open (IN, "<$quotefile") or return("No quote file supplied, or file not found ($quotefile)");
	#	rand($.) < 1 && ($line = $_) while <IN>; # Pick random line <- nulls the global array somehow.
	my @arr4 = (<IN>); # Slow with very large files, reads the whole lot into memory
	close(IN);
	my $line=$arr4[rand @arr4];;
	@arr4=undef; # Big array, better free it just to make sure.
	chomp($line);
	return $line;
	}

sub coloursay {# say something in pretty colours
	my $thing = shift;
	my $i=0;
	$thing =~ s{(.)}{"\cC" . (($i++%14)+2) . "$1"}eg;
	return "\002$thing";
	}