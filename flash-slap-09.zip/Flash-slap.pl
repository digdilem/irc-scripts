#!/usr/bin/perl
#
# irc-flash@digdilem.org - poke Flash_ at irc.quakenet.org - #3am
# If used in your own work, please include my name in it somewhere, thanks.
# 12th March, 2005
#
# Commands: (also adds buttons)
# "/rgive Nick"         - Give random object to Nick from objects.txt
# "/rslap Nick"         - As above, but abuse them with it first
# "/rmake Nick"         - Gives three random objects, asks Nick to build something
#
# v.0.9 - Also allows other people to prompt you to act with !slap, !give and !make
#
# Where is the objects.txt file? (Default - Xchat's windows' home)
# (This is the file containing random objects to give/slap with)
# Default - Windows XP's home directory for Xchat 2 - the same
# one perl scripts are loaded by default.
$objfile = "$ENV{'HOME'}/Application\ Data/X-Chat\ 2/objects.txt";
# Alternative for some windows that don't expand home directory: (Change username)
#$objectfile = "C:/Documents\ and\ Settings/username/Application\ Data/Xchat\ 2/objects.txt";
# If you still can't get it finding that file, plonk it somewhere else - it doesn't
# need to be in that dir.

# Do you want this script to add its own easy-use buttons below userlist? 
# (Change to 0 if not)
$flslap_buttons=1;
#
# Do you want others to be able to prompt you? !slap, !give and !make
$flap_silly_triggers=1;

#================== End of user config===========
$flslap_version = "0.9";
Xchat::register( "Flashy's Slap/Give Script", $flslap_version, "/rgive, /rmake and /rslap", "" );
Xchat::print "Loading Flashy's Slap/Give Script $flslap_version";

IRC::add_message_handler("PRIVMSG", "watch_slaptriggers");
IRC::add_command_handler("rgive", "rgive");
IRC::add_command_handler("rslap", "rslap");
IRC::add_command_handler("rmake", "rmake");

sub rgive {             # Randomly give an item to person from objects.txt       
         open (IN, "<$objfile") or (Xchat::print"Cannot open that file, wah! (Path: $objfile)");
         rand($.) < 1 && ($line = $_) while <IN>; # Pick random line
         close(IN);
         chomp($line);
         # Change wording if required
         IRC::command("/me gives $_[0] $line.");
         return 1;
}
sub rslap {             # Randomly slap somebody with an item to person from objects.txt
         open (IN, "<$objfile") or (Xchat::print"Cannot open that file, wah! (Path: $objfile)");
         rand($.) < 1 && ($line = $_) while <IN>; # Pick random line
         close(IN);
         chomp($line);
         # Change wording if required
         IRC::command("/me slaps $_[0] around the head with $line.");
         return 1;
}

sub rmake {
         open (IN, "<$objfile") or (Xchat::print"Cannot open that file, wah! (Path: $objfile)");
         rand($.) < 1 && ($line = $_) while <IN>; # Pick random line
         close(IN);
         open (IN, "<$objfile") or (Xchat::print"Cannot open that file, wah! (Path: $objfile)");
         rand($.) < 1 && ($line2 = $_) while <IN>; # Pick random line
         close(IN);
         open (IN, "<$objfile") or (Xchat::print"Cannot open that file, wah! (Path: $objfile)");
         rand($.) < 1 && ($line3 = $_) while <IN>; # Pick random line
         close(IN);
         chomp($line);
         chomp($line2);
         chomp($line3);
         # Change wording if required
         IRC::command("/me gives $_[0] $line, $line2 and $line3 - what can you make of them?");
         return 1;
}

# Add buttons if required
if ($flslap_buttons =~ /1/) {
        IRC::command "/delbutton RandGive";
        IRC::command "/delbutton RandSlap";
        IRC::command "/delbutton RandMake";
        
        IRC::command "/addbutton RandGive rgive %s";
        IRC::command "/addbutton RandSlap rslap %s";        
        IRC::command "/addbutton RandMake rmake %s";
}

sub watch_slaptriggers {
       if ($flap_silly_triggers) {
               foreach $line (@_) {
                        $line =~ m/\:(.*?)\!(.*?)\sPRIVMSG\s(.*?)\s\:(.*)?/;
                                       
                        $m_nick = $1;
                        $m_send = $2;
                        $m_chan = $3;
                        $m_line = $4;
                                       
                        $m_line =~ s/^\s+//; # Remove trailing whitespace
                        $m_line =~ s/\s+$//;
                        
                        if ($m_line =~ m/!slap/gi) { rslap($m_nick); }
                        if ($m_line =~ m/!give/gi) { rgive($m_nick); }
                        if ($m_line =~ m/!make/gi) { rmake($m_nick); }
                        }
       }
}
# Seed rand once
srand;