Flash's X-Chat scripts:
        irc-flash@digdilem.org
        Flash_ at #3am irc.quakenet.org and #perl irc.oftn.net
        
Written on and for Windows's X-Chat versions, although should run fine on Linux too with
a small adjustment of the home path. (Nice to turn the tables on all the linux-only scripts
available for X-Chat... :x )

Short Description:

Adds /rslap, /rmake and /rgive commands. Includes user-friendly buttons automatically added (toggle-able)
Eg:
        * Flash_ slaps Pengbot around the head with a red chinese dragon.
        * Flash_ gives Pengbot a snowplough, a pair of glasses and a book by Stephen King - what can you make of them?
        * Flash_ gives Pengbot Nessie the Loch Ness monster.
        
Also introduces !slap, !give and !make public commands (toggle in config) to enable/disable them.

History:
0.9     Added /rmake and public !give/!make/!slap commands.
0.8c    First version.
        
Installation:

0a. WINDOWS: YOU MUST HAVE THE PERL PLUGIN ENABLED AND PERL INSTALLED!
0b. LINUX: YOU MUST HAVE PERL INSTALLED!

1.
Copy the following files to your X-Chat's HOME directory. (The user's dir, not where you installed xchat)
        Under Windows XP - this dir is: "C:\Documents and Settings\YOUR_USER_NAME\Application Data\X-Chat 2". 
         When you find the right one you'll see a bunch of .conf files. You can quick-find by opening Logfiles 
         dir from Xchats prefs menu/logging and ascend one level. Note "Application Data" is set to HIDDEN by 
         default so you may not find it unless you enable hidden files in Explorer. 
         Yeah, I know - MS sucks, news at eleven.
        
        Under linux, it's "~/.xchat/" by default. 
        
        Flash-slap.pl   - The script
        objects.txt     - The objects. Simple one-per-line list of objects to give/slap with. 
                          Feel free to add/amend in your favourite text editor.
        
2.
If Linux, edit Flash-slap.pl and amend $objfile to something like "~/.xchat/" or whatever your xchat user dir is.
If Windows, no need to edit (unless you want to disable buttons)

3.
Load script in Xchat. Either use "/load "full path"" or the nice little popup menu. By placing .pl files in this 
folder, they are automatically loaded by Xchat on startup, so you could just restart Xchat and it should load.


On Success, you will notice "Loading Flashy's Slap/Give Script" printed somewhere, and two new buttons under the 
userlist. RandGive, RandMake and RandSlap. Select a user and click a button. You can select multiple users for mega-slaps too, 
using shift and ctrl + click on the userlist prior to hitting the button. You can just type "/rslap nick" manually 
if you like.

You can add these to a popup menu too, but Xchat doesn't appear to let me do that automatically, sorry!