#!/usr/bin/perl
#
# Flashy's bloodsports. http://digdilem.org/ - "Because thems trouts ain't gonna catch themselves!"
# (Credit to the original Eggdrop TCL script by Nerfbendr)
#
# Adds silly !hunt, !fish and !trophy public triggers
# Also !newmonth will clean out the trophy cupboard. (Only if you do it, or the nick in $owner_nick)
#
# Optional Configuration (Will work fine without changing these, but you can if you like)
my $owner_nick='Flash_'; # Your nick - you can only reset the scores remotely if you use this nick.
my $scale = 'kg'; # Say here whether you want to measure weights in lb or kg.
my $catch_percent=90; # How often you catch or shoot something.
my $trophy_cabinet = Xchat::get_info( 'xchatdir' ) . "\\trophies.txt"; # File to keep the trophies in.
# End user configuration
use strict;
Xchat::register( "Flashy's Huntin' 'n Fishin'", 'v.004', "Hunting", "" );
Xchat::hook_print('Channel Message', "hunting");
Xchat::hook_print('Your Message', "hunting");
Xchat::hook_print('Private Message', "hunting");
Xchat::hook_print('Private Message to Dialog', "hunting");
my $bigfish=0,my $fishman='Nobody',my $bighunt=0,my $huntman='Nobody';
my $fishtype='Trout',my $fishplace='Pool';
my $hunttype='bear', my $huntplace='Bushes';
my $last_hunter;
my $last_fisher;

my @hunts = ( "bear","gopher","rabbit","hunter","deer","fox","duck","moose","pokemon named Pikachu","park ranger","Yogi Bear","Boo Boo Bear","dog named Benji","cow","raccoon","koala bear","camper","channel lamer");
my @fish = ( "Salmon","Herring","Yellowfin Tuna","Pink Salmon","Chub","Barbel","Perch","Northern Pike","Brown Trout","Arctic Char","Roach","Brayling","Bleak","Cat Fish","Sun Fish","Old Tire","Rusty Tin Can","Genie Lamp","Love Message In A Bottle","Old Log","Rubber Boot","Dead Body","Loch Ness Monster","Old Fishing Lure","Piece of the Titanic","Chunk of Atlantis","Squid","Whale","Dolphin","Porpoise","Stingray","Submarine","Seal","Seahorse","Jellyfish","Starfish","Electric Eel","Great White Shark","Scuba Diver","X","Lag Monster","Virus","Soggy Pack of Smokes","Pile of Weed","Boat Anchor","Pair Of Floaties","Mermaid","Merman","Halibut","Tiddler","Sock","Trout");
my @huntplaces = ("in some bushes","in a hunting blind","in a hole","up in a tree","in a hiding place","out in the open","in the middle of a field","downtown","on a street corner","at the local mall");
my @fishplaces = ("Stream","Lake","River","Pond","Ocean","Bathtub","Kiddie's Swimming Pool","Toilet","Pile of Vomit","Pool of Urine","Kitchen Sink","Bathroom Sink","Mud Puddle","Pail of Water","Bowl of Jell-O (tm)","Wash Basin","Rain Barrel","Aquarium","SnowBank","WaterFall","Cup of Coffee","Glass of Milk");



Xchat::print("Path=($trophy_cabinet");

if (open (DH,"<$trophy_cabinet")) {
	($bigfish,$fishman,$fishtype,$fishplace) = split(/\|/,<DH>);
	chomp($fishplace);
	($bighunt,$huntman,$hunttype,$huntplace) = split(/\|/,<DH>);
	close (DH);
	Xchat::print("Peered in the trophy cabinet: ($bigfish$scale $fishtype by $fishman) ($bighunt$scale $hunttype by $huntman)");
	} else { 
	Xchat::print("\002Woo, looks like we've not gone hunting before. Let's make a trophy cabinet...");
	save_trophy();
	}
	
Xchat::print("\002Loaded Flash's Huntin' 'n Fishin'\002 (!hunt, !fish !trophy - Current records are $bigfish$scale and $bighunt$scale)");

sub hunting {
	my @pubwords = split(/ /,$_[0][1]);
	my $hunter = Xchat::strip_code($_[0][0]);
	my $channel = Xchat::get_info('channel');
	if (lc($pubwords[0]) eq '!hunt') {
		if ($hunter eq $last_hunter) { 
			Xchat::command("say Stop hogging all the best pitches $hunter, let someone else try first!");
			return Xchat::EAT_NONE;
			} else {
			$last_hunter = $hunter; 
			}
		my $huntplace = @huntplaces[rand(scalar @huntplaces)];
		my $hunt = @hunts[rand(scalar @hunts)];
		my $weight = 1+int(rand($bighunt+10));
		Xchat::command("msg $hunter You hide $huntplace and wait for something to wander by...");
		Xchat::command("msg $hunter .");
		Xchat::command("msg $hunter ..");
		Xchat::command("msg $hunter ...");
		Xchat::command("msg $hunter You think you hear something and fire wildly in that direction!");
		if (rand(100)<$catch_percent) {
			Xchat::command("msg $hunter Congratulations, $hunter! You just bagged yourself a $weight$scale $hunt!");
			Xchat::command("msg $channel $hunter just bagged a $weight$scale $hunt.");
			if ($weight > $bighunt) {
				Xchat::command("msg $hunter Wow!!! That's a new record! Way to go, $hunter! Type !trophy to see it!");
				Xchat::command("msg $channel Wow! That breaks the old record of a $bighunt$scale $hunttype! $hunter is amazing!");
				$bighunt=$weight;
				$huntman=$hunter;
				$hunttype=$hunt;
				save_trophy();
				}
		} else {
			Xchat::command("msg $hunter Rats...you missed it, $hunter! Better luck next time!");
			Xchat::command("msg $channel $hunter is useless, they missed by a mile!");
			}
		}	
	if (lc($pubwords[0]) eq '!fish') {
		$fishplace = @fishplaces[rand(scalar @fishplaces)];
		my $fishy = @fish[rand(scalar @fish)];
		my $weight = 1+int(rand($bigfish+10));
		if ($hunter eq $last_fisher) { 
			Xchat::command("say Stop hogging all the best pitches $hunter, let someone else try first!");
			return Xchat::EAT_NONE;
			} else {
			$last_fisher = $hunter; 
			}
		Xchat::command("msg $hunter You cast your line into a $fishplace and wait for a bite...");
		Xchat::command("msg $hunter .");
		Xchat::command("msg $hunter ..");
		Xchat::command("msg $hunter ...");
		Xchat::command("msg $hunter You feel a tug on your line and reel it in...");
		if (rand(100)<$catch_percent) {
			Xchat::command("msg $hunter Congratulations, $hunter! You just caught yourself a $weight$scale $fishy!");
			Xchat::command("msg $channel $hunter just caught a $weight$scale $fishy");
			if ($weight > $bigfish) {
				Xchat::command("msg $hunter Wow!!! That's a new record! Way to go, $hunter! Type !trophy to see it!");
				Xchat::command("msg $channel Brilliant! That breaks the old record of a $bigfish$scale $fishtype! $hunter is the world's best!");
				$fishman=$hunter;
				$bigfish=$weight;
				$fishtype=$fishy;
				save_trophy();
				}
		} else {
			Xchat::command("msg $hunter Rats...it got away, $hunter! Better luck next time!");
			Xchat::command("msg $channel $hunter is useless, they failed to catch anything!");
			}
		}
	if (lc($pubwords[0]) eq '!trophy') {
		Xchat::command("say $fishman holds the fishing record when they caught a $bigfish$scale $fishtype");
		Xchat::command("say $huntman holds the hunting record when they bagged a $bighunt$scale $hunttype");
		}

	if (lc($pubwords[0]) eq '!newmonth') {		
		my $curnick = Xchat::get_info('nick');
		if ((lc($hunter) eq lc($owner_nick)) or ($hunter eq Xchat::get_info('nick'))) {
			$bigfish=0; $fishman='Nobody'; $fishtype='Tiddler'; $fishplace='Toilet'; 
			$bighunt=0; $huntman='Nobody'; $hunttype='Haggis'; $huntplace='Bush';
			save_trophy();
			Xchat::command("say It's a new month, all existing huntin' 'n fishin' records are reset!");
			} else { Xchat::command("say Who are you, $hunter to tell me to change the month?"); }
		} 
}

sub save_trophy {
	open (DH, ">$trophy_cabinet") or die("Bah! Can't open the trophy cabinet to push this 'ere trophy in!");
	print (DH "$bigfish|$fishman|$fishtype|$fishplace\n");
	print (DH "$bighunt|$huntman|$hunttype|$huntplace");
	close (DH);
	}
	