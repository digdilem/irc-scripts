NickColourScript

By Motig


-------

Installation:

NickColourScript doesn't work with NoNameScript, and may not work with other scripts that modify the way messages look in channels. 'Double messages' is a common error resulting from a conflicting script. Sorry- I may try to get the script to be more compatible with other large scripts.

Put the file nickcolourscript.mrc on your C drive. Now, open mIRC, type the following in anywhere and press enter:

/load -rs "C:\nickcolourscript.mrc"

Two notes:

 	1 - If you put the file in a different place on your hardrive, that's fine, just change the /load command accordingly, the above is only an example.
	2 - I'm British, so colour has a 'u'- watch your spelling if it says file not found or something. :D :P


Make sure you click 'YES' when asked whether or not you wish to run initialisation commands!



------

How the script works:

Once you load the script, it will automatically start detecting other users who have NCS and will colour their names for you. If at any time you wish to turn name colouring off, type /ncs. Again, to turn the script on, /ncs is the command to use.

To colour your own name, go to http://motig.clanservers.com/NickColourScript/index.php and register your IRC nick. There're only 4 fields to fill in, and it takes literally 20 seconds. The webpage expects you to use standard mIRC colour codes (i.e. CTRL + K).

At this page you can also edit the colours for a previously registered nick with the second set of text boxes at the bottom of the page.


Finally, please note that the script attempts to minimize server load, so you may not see updated colours for yourself or your friends immediately.



Motig @ Furnet or Quakenet

#nickcolourscript @ Quakenet :]